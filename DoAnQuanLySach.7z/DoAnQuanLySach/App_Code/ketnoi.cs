﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

/// <summary>
/// Summary description for ketnoi
/// </summary>
public class ketnoi
{
    public SqlConnection kn = new SqlConnection(WebConfigurationManager.ConnectionStrings["strcon"].ConnectionString);
	public void ketnoi_sql()
	{
        
        kn.Open();
		//
		// TODO: Add constructor logic here
		//
	}
    //Đóng kết nối tới CSDL
    public void dongketnoi()
    {
        if (kn.State == ConnectionState.Open)
        { kn.Close(); }
    }


    //Khi muốn lấy bảng dữ liệu thì: ketnoi.laybang(“Bỏ câu sql lấy bảng vào đây”);
    public DataTable bangdulieu = new DataTable();
    public DataTable laybang(string caulenh)
    {
        try
        {
            ketnoi_sql();
            SqlDataAdapter Adapter = new SqlDataAdapter(caulenh, kn);
            DataSet ds = new DataSet();

            Adapter.Fill(bangdulieu);
        }
        catch (System.Exception)
        {
            bangdulieu = null;
        }
        finally
        {
            dongketnoi();
        }

        return bangdulieu;
    }


    //Khi muốn cập nhật: thêm, xóa, sửa, delete thì dùng class ketnoi.xulydulieu(“bỏ câu sql vào”);
    public int xulydulieu(string caulenhsql)
    {
        int kq = 0;
        try
        {
            ketnoi_sql();
            SqlCommand lenh = new SqlCommand(caulenhsql, kn);
            kq = lenh.ExecuteNonQuery();        //kq cho giá trị là một số lớn hơn không
        }
        catch (Exception ex)
        {
            //Thông báo lỗi ra!

            kq = 0;
        }
        finally
        {
            dongketnoi();
        }
        return kq;
    }



    //Khi muốn lấy 1 giá trị (khi muốn lấy một cột gồm nhiều giá trị) từ câu select thì ketnoi.lay1giatri(“bỏ câu sql vào”);
    //Lưu ý trường muốn lấy phải đổi tên thành ‘tong’
    //Thí dụ : select sotien as ‘tong’ from ctphieu
    public string lay1giatri(string sql)
    {
        string kq = "";
        try
        {
            ketnoi_sql();

            SqlCommand sqlComm = new SqlCommand(sql, kn);
            SqlDataReader r = sqlComm.ExecuteReader();
            if (r.Read())
            {
                kq = r["tong"].ToString();
            }
        }
        catch
        { }
        return kq;
    }
}

