﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SachTheoTheLoai : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ViewState["MaLoaiLayDuoc"] = int.Parse(Request.QueryString.Get("MaLoai"));
            laybangchogridview();
            DemSoMauTinTuongUngVoiTheLoaiSachDuocChon();
        }
    }


    public void laybangchogridview()
    {
        ketnoi kn = new ketnoi();
        DataTable dt = new DataTable();
        dt = kn.laybang("select * from Sach where MaLoai=" + (int)ViewState["MaLoaiLayDuoc"]);
        DataList1.DataSource = dt;
        DataList1.DataBind();
    }


    public void DemSoMauTinTuongUngVoiTheLoaiSachDuocChon()
    {
        // Tạo đối tượng Connection và mở kết nối đến CSDL SQL Server
        string chuoiketnoi = "Server=LAPOFVINH\SQLEXPRESS; Integrated Security=true; Database=SachOnline";
        SqlConnection Conn = new SqlConnection(chuoiketnoi);
        Conn.Open();


        // Tạo đối tượng Command và select toàn bộ bảng Sach
        SqlCommand Cmd;
        Cmd = new SqlCommand();
        Cmd.CommandText = "Select Count(*) from Sach where MaLoai=" + (int)ViewState["MaLoaiLayDuoc"];
        Cmd.Connection = Conn;

        // Hiển thị kết quả trên Label
        int SL = (int)Cmd.ExecuteScalar();
        lblTongSoSach.Text = "Tìm được [" + SL.ToString() + "] sách";

        // Giải phóng kết nối. 
        Cmd.Dispose();
        Conn.Close();

    }
}